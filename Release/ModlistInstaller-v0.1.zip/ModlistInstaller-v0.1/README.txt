ModListInstaller v0.1

Run modlist-packer.exe to create a release folder.
The packer copies the bundled modlist-installer.exe and data/ui into each package it creates.
