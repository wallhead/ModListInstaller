ModListInstaller v0.2

Run modlist-packer.exe to create a release folder.
The installer expects manifest.json in data\package, archives in data\downloads, and UI files in data\ui.
